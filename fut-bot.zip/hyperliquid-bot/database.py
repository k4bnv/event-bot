"""
database.py — SQLite-персистентность для Paper Trading бота.

Хранит:
  • state          — баланс, стартовый баланс, последний обработанный бар.
  • positions      — активные виртуальные позиции (одна за раз).
  • trades         — закрытые сделки.
  • equity_curve   — кривая эквити для графика (/chart).

Файл БД: /data/paper.db (Docker volume).
"""

import os
import sqlite3
from pathlib import Path

DATA_DIR = Path(os.getenv("DATA_DIR", "/data"))
DB_PATH = DATA_DIR / "paper.db"

SCHEMA = """
CREATE TABLE IF NOT EXISTS state (
    key TEXT PRIMARY KEY,
    value TEXT
);
CREATE TABLE IF NOT EXISTS positions (
    symbol TEXT PRIMARY KEY,
    side TEXT,
    entry_price REAL,
    stop_loss REAL,
    notional REAL,
    margin REAL,
    qty REAL,
    atr REAL,
    open_ts TEXT,
    open_candle_ts INTEGER,
    entry_candle_low REAL
);
CREATE TABLE IF NOT EXISTS trades (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    symbol TEXT,
    side TEXT,
    entry_price REAL,
    exit_price REAL,
    notional REAL,
    margin REAL,
    gross_pnl REAL,
    costs REAL,
    net_pnl REAL,
    reason TEXT,
    open_ts TEXT,
    close_ts TEXT,
    balance_after REAL,
    win INTEGER
);
CREATE TABLE IF NOT EXISTS equity_curve (
    ts INTEGER PRIMARY KEY,
    equity REAL,
    balance REAL
);
CREATE TABLE IF NOT EXISTS trailing_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    symbol TEXT,
    old_sl REAL,
    new_sl REAL,
    ts TEXT
);
"""


def get_conn():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA busy_timeout=10000")
    return conn


def init_db(start_balance=100.0):
    conn = get_conn()
    conn.executescript(SCHEMA)
    cur = conn.execute("SELECT value FROM state WHERE key='balance'")
    row = cur.fetchone()
    if row is None:
        conn.execute("INSERT INTO state(key,value) VALUES('balance',?)", (str(float(start_balance)),))
        conn.execute("INSERT INTO state(key,value) VALUES('start_balance',?)", (str(float(start_balance)),))
    conn.commit()
    conn.close()


# ----------------------------- state ----------------------------------------
def get_state(key, default=None):
    conn = get_conn()
    row = conn.execute("SELECT value FROM state WHERE key=?", (key,)).fetchone()
    conn.close()
    return row[0] if row else default


def set_state(key, value):
    conn = get_conn()
    conn.execute("INSERT OR REPLACE INTO state(key,value) VALUES(?,?)", (key, str(value)))
    conn.commit()
    conn.close()


def get_balance():
    return float(get_state("balance", "0"))


def get_start_balance():
    return float(get_state("start_balance", "100"))


def set_balance(b):
    set_state("balance", float(b))


# ----------------------------- positions ------------------------------------
def get_open_position():
    """Возвращает единственную открытую позицию (или None)."""
    conn = get_conn()
    rows = conn.execute("SELECT * FROM positions").fetchall()
    conn.close()
    return dict(rows[0]) if rows else None


def get_all_positions():
    conn = get_conn()
    rows = conn.execute("SELECT * FROM positions").fetchall()
    conn.close()
    return [dict(r) for r in rows]


def save_position(pos):
    conn = get_conn()
    conn.execute(
        """INSERT OR REPLACE INTO positions
           (symbol,side,entry_price,stop_loss,notional,margin,qty,atr,open_ts,open_candle_ts,entry_candle_low)
           VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
        (pos["symbol"], pos["side"], pos["entry_price"], pos["stop_loss"],
         pos["notional"], pos["margin"], pos["qty"], pos.get("atr"),
         pos.get("open_ts"), pos.get("open_candle_ts"), pos.get("entry_candle_low")),
    )
    conn.commit()
    conn.close()


def update_stop_loss(symbol, sl):
    conn = get_conn()
    conn.execute("UPDATE positions SET stop_loss=? WHERE symbol=?", (sl, symbol))
    conn.commit()
    conn.close()


def delete_position(symbol):
    conn = get_conn()
    conn.execute("DELETE FROM positions WHERE symbol=?", (symbol,))
    conn.commit()
    conn.close()


# ----------------------------- trades ---------------------------------------
def add_trade(t):
    conn = get_conn()
    conn.execute(
        """INSERT INTO trades
           (symbol,side,entry_price,exit_price,notional,margin,gross_pnl,costs,net_pnl,
            reason,open_ts,close_ts,balance_after,win)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (t["symbol"], t["side"], t["entry_price"], t["exit_price"],
         t["notional"], t["margin"], t["gross_pnl"], t["costs"], t["net_pnl"],
         t["reason"], t["open_ts"], t["close_ts"], t["balance_after"], int(t["win"])),
    )
    conn.commit()
    conn.close()


def get_trades(limit=100):
    conn = get_conn()
    rows = conn.execute("SELECT * FROM trades ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_trade_count():
    conn = get_conn()
    r = conn.execute("SELECT COUNT(*) AS c FROM trades").fetchone()
    conn.close()
    return r["c"]


def get_closed_trades_for_stats():
    conn = get_conn()
    rows = conn.execute("SELECT net_pnl, win FROM trades ORDER BY id ASC").fetchall()
    conn.close()
    return [dict(r) for r in rows]


# ----------------------------- equity ---------------------------------------
def add_equity_point(ts, equity, balance):
    conn = get_conn()
    conn.execute(
        "INSERT OR REPLACE INTO equity_curve(ts,equity,balance) VALUES(?,?,?)",
        (int(ts), float(equity), float(balance)),
    )
    conn.commit()
    conn.close()


def get_equity_curve(limit=10000):
    conn = get_conn()
    rows = conn.execute(
        "SELECT * FROM equity_curve ORDER BY ts ASC LIMIT ?", (limit,)
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


# ----------------------------- trailing log ---------------------------------
def add_trailing_log(symbol, old_sl, new_sl):
    conn = get_conn()
    from datetime import datetime, timezone
    conn.execute(
        "INSERT INTO trailing_log(symbol,old_sl,new_sl,ts) VALUES(?,?,?,?)",
        (symbol, old_sl, new_sl, datetime.now(timezone.utc).isoformat()),
    )
    conn.commit()
    conn.close()
