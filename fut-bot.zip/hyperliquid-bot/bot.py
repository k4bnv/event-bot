#!/usr/bin/env python3
"""
================================================================================
 Market Structure Accelerated (15m) Unthrottled — Paper Trading Bot
================================================================================
 Live виртуальный торговый бот для Hyperliquid (публичный API ccxt, без приватных
 ключей). Стратегия: Long-Only Market Structure Breakout + Fib pullback + trailing.

 • 8 пар (NEAR, EGLD, ETH, SOL, AVAX, SUI, APT, LINK).
 • Макро-фильтр 1D: BTC Close > BTC EMA(50) — иначе бот в 100% USDC.
 • Фильтр тренда 4H: EMA(20) > EMA(50).
 • Вход 15m: слом структуры (Close > High за 12 свечей) + откат в Fib 0.382–0.618.
 • Выход: трейлинг под 15m Swing Low (10 свечей). Без фиксированного TP.
 • Риск 2.5%, плечо 3x, комиссия 0.05% (Hyperliquid).
 • БЕЗ предохранителей: 100% сигналов исполняются 24/7 без пауз на просадку.

 Telegram: авто-алерты (вход/трейлинг/закрытие) + команды
   /start /balance /stats /position /chart

 Запуск: python bot.py  (или docker compose up -d --build)
================================================================================
"""

import os
import io
import time
import asyncio
import logging
from datetime import datetime, timezone

import ccxt
import pandas as pd
import pandas_ta as ta
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from dotenv import load_dotenv

from aiogram import Bot, Dispatcher
from aiogram.filters import Command
from aiogram.types import Message
from aiogram.enums import ParseMode
from aiogram.client.default import DefaultBotProperties
from aiogram.exceptions import TelegramRetryAfter, TelegramAPIError
from apscheduler.schedulers.asyncio import AsyncIOScheduler

import database as db


# ============================== Конфигурация =================================
load_dotenv()

TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
TELEGRAM_ADMIN_ID_RAW = os.getenv("TELEGRAM_ADMIN_ID", "").strip()
TELEGRAM_ADMIN_ID = int(TELEGRAM_ADMIN_ID_RAW) if TELEGRAM_ADMIN_ID_RAW.isdigit() else None

EXCHANGE_NAME = os.getenv("EXCHANGE", "hyperliquid").strip().lower()
SYMBOL_QUOTE = os.getenv("SYMBOL_QUOTE", "USDC").strip().upper()
# Финальная корзина из 9 монет (по итогам бэктеста 365д, PF 1.43, Sharpe 1.90)
COINS = [c.strip().upper() for c in os.getenv(
    "COINS", "MERL,TIA,ORDI,PEOPLE,APE,MORPHO,PYTH,AXS,ETH").split(",") if c.strip()]
# Для Hyperliquid используем perp-формат BASE/USDC:USDC, для других бирж — BASE/QUOTE
if EXCHANGE_NAME == "hyperliquid":
    SYMBOLS = [f"{c}/{SYMBOL_QUOTE}:{SYMBOL_QUOTE}" for c in COINS]
    BTC_SYMBOL = f"BTC/{SYMBOL_QUOTE}:{SYMBOL_QUOTE}"
else:
    SYMBOLS = [f"{c}/{SYMBOL_QUOTE}" for c in COINS]
    BTC_SYMBOL = f"BTC/{SYMBOL_QUOTE}"

START_BALANCE = float(os.getenv("START_BALANCE", "100"))
LEVERAGE = int(os.getenv("LEVERAGE", "3"))
RISK_PERCENT = float(os.getenv("RISK_PERCENT", "0.025"))
COMMISSION_RATE = float(os.getenv("COMMISSION_RATE", "0.0005"))   # 0.05% за сторону
ROUND_TRIP_COST = COMMISSION_RATE * 2                              # 0.10% за круг
CYCLE_SECONDS = int(os.getenv("CYCLE_SECONDS", "60"))
MAX_POSITIONS = int(os.getenv("MAX_POSITIONS", "3"))   # до 3 одновременных позиций

# Параметры стратегии
BREAKOUT_LEN = 12        # High за 12 предыдущих свечей (MSB)
SWING_LOW_LEN = 12       # Swing low для трейлинга (минимум за 12 свечей)
LOOKBACK_AFTER = 12      # окно после слома, в течение которого ждём откат
ATR_LEN = 14
FIB_DEEP = 0.618         # глубокая граница отката
FIB_SHALLOW = 0.382      # мелкая граница отката
MACRO_EMA_LEN = 50      # BTC 1D EMA(50)
EMA_FAST_4H = 20
EMA_SLOW_4H = 50

TF_15M = "15m"
TF_4H = "4h"
TF_1D = "1d"
TF_15M_SEC = 900

# ============================== Логирование =================================
logging.basicConfig(
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    level=logging.INFO,
    datefmt="%Y-%m-%d %H:%M:%S",
)
logging.getLogger("ccxt").setLevel(logging.WARNING)
logging.getLogger("apscheduler").setLevel(logging.WARNING)
logging.getLogger("aiogram").setLevel(logging.INFO)
log = logging.getLogger("ms-bot")


# ============================== Биржа + кэш =================================
def make_exchange():
    """Создаёт публичный клиент биржи (приватные ключи НЕ НУЖНЫ).

    Для Hyperliquid НЕ устанавливаем defaultType=spot — иначе perp-символы
    (BASE/USDC:USDC) возвращают ошибку. Hyperliquid сам определяет тип по символу.
    """
    klass = getattr(ccxt, EXCHANGE_NAME, None)
    if klass is None:
        raise RuntimeError(f"Биржа '{EXCHANGE_NAME}' не поддерживается ccxt.")
    if EXCHANGE_NAME == "hyperliquid":
        return klass({"enableRateLimit": True, "rateLimit": 250})
    return klass({"enableRateLimit": True, "options": {"defaultType": "spot"}})


ex = make_exchange()

# кэш данных: (symbol, tf) -> (df, fetch_ts); TTL по таймфрейму
_CACHE_TTL = {TF_15M: 45, TF_4H: 300, TF_1D: 3600}
_data_cache = {}

# Активные символы (фильтруются по доступности на бирже при старте)
ACTIVE_SYMBOLS = []


def load_available_symbols():
    """Фильтрует SYMBOLS по доступности на бирже (load_markets).

    Для Hyperliquid проверяет, что символ существует как swap (perp).
    Для других бирж — просто наличие символа.
    """
    global ACTIVE_SYMBOLS
    # retry для устойчивости к rate-limit
    markets = None
    for attempt in range(5):
        try:
            markets = ex.load_markets()
            break
        except Exception as e:
            if "429" in str(e) or "RateLimit" in type(e).__name__:
                wait = 2 ** attempt * 5
                log.warning("load_markets rate-limited (попытка %d/5), ждём %ss...", attempt + 1, wait)
                import time as _t
                _t.sleep(wait)
            else:
                log.error("load_markets failed: %s — используются все SYMBOLS", e)
                ACTIVE_SYMBOLS = SYMBOLS
                return
    if markets is None:
        log.error("load_markets не удалось после 5 попыток — используются все SYMBOLS")
        ACTIVE_SYMBOLS = SYMBOLS
        return

    available = []
    missing = []
    for s in SYMBOLS:
        m = markets.get(s)
        if m is None:
            missing.append(s)
            continue
        # Hyperliquid: нужен swap (perp), не spot
        if EXCHANGE_NAME == "hyperliquid" and not m.get("swap"):
            missing.append(f"{s} (только spot)")
            continue
        available.append(s)
    if not available:
        log.error("Ни один символ из %s не найден как swap на %s. "
                  "Проверьте SYMBOL_QUOTE/COINS.", SYMBOLS, EXCHANGE_NAME)
    if missing:
        log.warning("Недоступны на %s (пропуск): %s", EXCHANGE_NAME, ", ".join(missing))
    ACTIVE_SYMBOLS = available


def fetch_ohlcv_df(symbol, timeframe, limit=100):
    """Синхронная загрузка OHLCV через ccxt (вызывать в потоке)."""
    ohlcv = ex.fetch_ohlcv(symbol, timeframe=timeframe, limit=limit)
    if not ohlcv:
        return None
    df = pd.DataFrame(ohlcv, columns=["timestamp", "open", "high", "low", "close", "volume"])
    df["datetime"] = pd.to_datetime(df["timestamp"], unit="ms")
    return df


def fetch_cached(symbol, timeframe, limit=100):
    now = time.time()
    key = (symbol, timeframe)
    ttl = _CACHE_TTL.get(timeframe, 60)
    cached = _data_cache.get(key)
    if cached and (now - cached[1]) < ttl:
        return cached[0]
    try:
        df = fetch_ohlcv_df(symbol, timeframe, limit=limit)
        if df is not None:
            _data_cache[key] = (df, now)
        return df
    except Exception as e:
        log.warning("[%s %s] ошибка загрузки: %s", symbol, timeframe, e)
        # вернуть устаревший кэш, если есть
        if cached:
            return cached[0]
        return None


# ============================== Индикаторы ==================================
def compute_15m_indicators(df):
    df = df.copy()
    df["hh"] = df["high"].rolling(BREAKOUT_LEN).max().shift(1)
    df["ll"] = df["low"].rolling(BREAKOUT_LEN).min().shift(1)
    df["swing_low"] = df["low"].rolling(SWING_LOW_LEN).min()
    df["atr"] = ta.atr(df["high"], df["low"], df["close"], length=ATR_LEN)
    df["broke_up"] = df["close"] > df["hh"]
    df["recent_break"] = df["broke_up"].rolling(LOOKBACK_AFTER).max().fillna(0).astype(bool)
    df["fib_zone_low"] = df["hh"] - FIB_DEEP * (df["hh"] - df["ll"])
    df["fib_zone_high"] = df["hh"] - FIB_SHALLOW * (df["hh"] - df["ll"])
    return df


def compute_btc_macro(df):
    df = df.copy()
    df["ema50"] = ta.ema(df["close"], length=MACRO_EMA_LEN)
    return df


def compute_4h_trend(df):
    df = df.copy()
    df["ema20"] = ta.ema(df["close"], length=EMA_FAST_4H)
    df["ema50"] = ta.ema(df["close"], length=EMA_SLOW_4H)
    return df


def last_closed_candle(df, tf_seconds):
    """Возвращает (row, index) последней ЗАКРЫТОЙ свечи."""
    if df is None or len(df) == 0:
        return None, -1
    now_ms = int(time.time() * 1000)
    for i in range(len(df) - 1, -1, -1):
        if df.iloc[i]["timestamp"] + tf_seconds * 1000 <= now_ms:
            return df.iloc[i], i
    return df.iloc[-1], len(df) - 1


# ============================== Сигнал входа ================================
def evaluate_entry(row_15m, btc_bullish, trend_4h_ok):
    """Возвращает {symbol, side, entry, sl, atr, swing_low} или None."""
    if not btc_bullish:
        return None
    if not trend_4h_ok:
        return None

    close = row_15m["close"]
    low = row_15m["low"]
    hh = row_15m["hh"]
    atr = row_15m["atr"]
    fib_low = row_15m["fib_zone_low"]
    fib_high = row_15m["fib_zone_high"]
    recent_break = row_15m["recent_break"]
    swing_low = row_15m["swing_low"]

    if pd.isna(atr) or atr <= 0 or pd.isna(hh) or pd.isna(fib_low) or pd.isna(fib_high):
        return None
    if not recent_break:
        return None
    # текущая свеча — откат в зону Fib
    if not (fib_low <= close <= fib_high):
        return None
    if not (low <= fib_high):
        return None

    # начальный SL под Swing Low импульсной свечи входа
    if pd.isna(swing_low) or swing_low >= close:
        sl = float(close) - 1.5 * float(atr)   # защитный fallback
    else:
        sl = float(swing_low)
    if sl >= close:
        return None

    return {
        "side": "long",
        "entry": float(close),
        "sl": sl,
        "atr": float(atr),
        "swing_low": float(swing_low) if not pd.isna(swing_low) else sl,
        "candle_low": float(low),
        "candle_ts": int(row_15m["timestamp"]),
    }


def compute_position_size(balance, entry, sl, leverage):
    """Размер позиции по риску 2.5% (с ограничением по плечу)."""
    sl_pct = abs(entry - sl) / entry
    if sl_pct <= 0:
        return None
    risk_amount = balance * RISK_PERCENT
    notional = risk_amount / sl_pct
    max_notional = balance * leverage
    notional = min(notional, max_notional)
    margin = notional / leverage
    qty = notional / entry
    return {"notional": notional, "margin": margin, "qty": qty}


# ============================== Telegram helpers ============================
async def notify(bot, text):
    if not TELEGRAM_BOT_TOKEN or TELEGRAM_ADMIN_ID is None:
        return
    try:
        await bot.send_message(TELEGRAM_ADMIN_ID, text, parse_mode=ParseMode.HTML,
                               disable_web_page_preview=True)
    except TelegramRetryAfter as e:
        log.warning("Telegram flood: ждём %ss", e.retry_after)
        await asyncio.sleep(e.retry_after)
    except TelegramAPIError as e:
        log.warning("Telegram error: %s", e)
    except Exception as e:
        log.warning("notify: %s: %s", type(e).__name__, e)


def fmt_money(x):
    return f"+{x:,.2f}" if x >= 0 else f"{x:,.2f}"


# ============================== Управление позицией =========================
async def manage_open_position(bot, pos, df_15m_coin, df_4h_coin, closed_candle_idx):
    """Проверка трейлинга и выхода для открытой позиции.

    Возвращает True, если позиция закрыта.
    """
    if df_15m_coin is None or len(df_15m_coin) == 0:
        return False

    latest = df_15m_coin.iloc[-1]
    sl = pos["stop_loss"]
    exit_price = None
    reason = None

    # 1) Интрабар выход по стопу: low последней (формирующейся) свечи <= SL
    if not pd.isna(latest["low"]) and latest["low"] <= sl:
        exit_price = sl
        reason = "trail_sl"

    # 2) Трейлинг по новой закрытой свече
    if exit_price is None and closed_candle_idx >= 0:
        closed = df_15m_coin.iloc[closed_candle_idx]
        new_swing = closed["swing_low"]
        if not pd.isna(new_swing) and new_swing > sl:
            old_sl = sl
            sl = float(new_swing)
            db.update_stop_loss(pos["symbol"], sl)
            db.add_trailing_log(pos["symbol"], old_sl, sl)
            await notify(bot,
                f"⬆️ <b>ТРЕЙЛИНГ</b> · {pos['symbol']}\n"
                f"SL: ${old_sl:,.4f} → <b>${sl:,.4f}</b>\n"
                f"Текущая цена: ${latest['close']:,.4f}")

    if exit_price is not None:
        await close_position(bot, pos, exit_price, reason)
        return True
    return False


async def close_position(bot, pos, exit_price, reason):
    """Закрывает позицию, считает PnL, обновляет баланс, шлёт алерт."""
    entry = pos["entry_price"]
    notional = pos["notional"]
    gross = (exit_price - entry) / entry * notional
    costs = notional * ROUND_TRIP_COST
    net = gross - costs
    balance = db.get_balance() + net
    db.set_balance(balance)
    is_win = net >= 0

    db.add_trade({
        "symbol": pos["symbol"], "side": pos["side"],
        "entry_price": entry, "exit_price": exit_price,
        "notional": notional, "margin": pos["margin"],
        "gross_pnl": gross, "costs": costs, "net_pnl": net,
        "reason": reason,
        "open_ts": pos["open_ts"],
        "close_ts": datetime.now(timezone.utc).isoformat(),
        "balance_after": balance, "win": is_win,
    })
    db.delete_position(pos["symbol"])

    emoji = "✅" if reason == "tp" else ("❌" if not is_win else "🟰")
    reason_txt = {"trail_sl": "Трейлинг-стоп 🛑", "init_sl": "Стоп-лосс 🛑",
                  "force": "Принудительное закрытие", "tp": "Тейк-профит 🎯"}.get(reason, reason)
    pnl_pct = net / pos["margin"] * 100 if pos["margin"] else 0
    color = "🟢" if net >= 0 else "🔴"
    log.info("[ЗАКРЫТИЕ] %s | %s | net=%.2f | balance=%.2f", pos["symbol"], reason, net, balance)

    await notify(bot,
        f"{emoji} <b>ЗАКРЫТИЕ сделки</b> · {pos['symbol']}\n"
        f"━━━━━━━━━━━━━━━━━━━━\n"
        f"📈 LONG\n"
        f"Вход: ${entry:,.4f} → Выход: ${exit_price:,.4f}\n"
        f"Причина: {reason_txt}\n"
        f"━━━━━━━━━━━━━━━━━━━━\n"
        f"{color} Чистый PnL: <b>{fmt_money(net)}$</b> ({fmt_money(pnl_pct)}%)\n"
        f"💼 Комиссии: -{costs:.4f}$\n"
        f"━━━━━━━━━━━━━━━━━━━━\n"
        f"💰 Баланс: <b>${balance:,.2f}</b>")


async def try_open_position(bot, df_15m_map, df_4h_map, btc_bullish):
    """Сканирует монеты на сигнал входа, открывает до MAX_POSITIONS позиций.

    Не открывает позицию по монете, где уже есть открытая. За один цикл может
    открыть несколько позиций (по разным монетам), пока не достигнут лимит.
    """
    open_positions = db.get_all_positions()
    if len(open_positions) >= MAX_POSITIONS:
        return  # лимит позиций достигнут
    open_symbols = {p["symbol"] for p in open_positions}
    slots_left = MAX_POSITIONS - len(open_positions)

    for symbol in (ACTIVE_SYMBOLS or SYMBOLS):
        if slots_left <= 0:
            break
        if symbol in open_symbols:
            continue  # по этой монете уже есть позиция
        df15 = df_15m_map.get(symbol)
        df4 = df_4h_map.get(symbol)
        if df15 is None or df4 is None:
            continue
        df15 = compute_15m_indicators(df15)
        closed, idx = last_closed_candle(df15, TF_15M_SEC)
        if closed is None:
            continue
        df4 = compute_4h_trend(df4)
        closed4, _ = last_closed_candle(df4, 4 * 3600)
        trend_4h_ok = (closed4 is not None and not pd.isna(closed4["ema20"])
                       and not pd.isna(closed4["ema50"]) and closed4["ema20"] > closed4["ema50"])
        sig = evaluate_entry(closed, btc_bullish, trend_4h_ok)
        if not sig:
            continue

        balance = db.get_balance()
        sizing = compute_position_size(balance, sig["entry"], sig["sl"], LEVERAGE)
        if sizing is None:
            continue
        pos = {
            "symbol": symbol,
            "side": sig["side"],
            "entry_price": sig["entry"],
            "stop_loss": sig["sl"],
            "notional": sizing["notional"],
            "margin": sizing["margin"],
            "qty": sizing["qty"],
            "atr": sig["atr"],
            "open_ts": datetime.now(timezone.utc).isoformat(),
            "open_candle_ts": sig["candle_ts"],
            "entry_candle_low": sig["candle_low"],
        }
        db.save_position(pos)
        log.info("[ВХОД] %s LONG @ %s SL=%s notional=%s (позиций: %d/%d)",
                 symbol, sig["entry"], sig["sl"], sizing["notional"],
                 len(open_positions) + 1, MAX_POSITIONS)

        fib_low = closed["fib_zone_low"]
        fib_high = closed["fib_zone_high"]
        await notify(bot,
            f"🟢 <b>ВХОД LONG</b> · {symbol}\n"
            f"━━━━━━━━━━━━━━━━━━━━\n"
            f"💰 Цена входа: <b>${sig['entry']:,.4f}</b>\n"
            f"📊 Размер: ${sizing['notional']:,.2f} (маржа ${sizing['margin']:.2f})\n"
            f"📦 Объём: {sizing['qty']:.4f}\n"
            f"━━━━━━━━━━━━━━━━━━━━\n"
            f"🛑 Stop-Loss: <b>${sig['sl']:,.4f}</b> (Swing Low)\n"
            f"🎯 Выход: трейлинг по 15m Swing Low (без TP)\n"
            f"━━━━━━━━━━━━━━━━━━━━\n"
            f"ATR(14): {sig['atr']:.4f}  |  Fib: {fib_low:,.4f}–{fib_high:,.4f}\n"
            f"📈 BTC макро: {'бычий ✅' if btc_bullish else 'медвежий ❌'}\n"
            f"📊 Открыто позиций: {len(open_positions) + 1}/{MAX_POSITIONS}")
        open_symbols.add(symbol)
        open_positions = db.get_all_positions()
        slots_left = MAX_POSITIONS - len(open_positions)


# ============================== Главный цикл ================================
_last_equity_ts = 0


async def strategy_cycle(bot):
    """Один такт стратегии: проверка позиции + вход; без предохранителей."""
    try:
        # макро BTC 1D
        df_btc = await asyncio.to_thread(fetch_cached, BTC_SYMBOL, TF_1D, 120)
        btc_bullish = False
        if df_btc is not None:
            df_btc = compute_btc_macro(df_btc)
            c, _ = last_closed_candle(df_btc, 86400)
            if c is not None and not pd.isna(c["ema50"]):
                btc_bullish = c["close"] > c["ema50"]

        # 15m + 4H по всем активным монетам
        syms = ACTIVE_SYMBOLS or SYMBOLS
        df_15m_map = {}
        df_4h_map = {}
        for symbol in syms:
            df_15m_map[symbol] = await asyncio.to_thread(fetch_cached, symbol, TF_15M, 100)
            df_4h_map[symbol] = await asyncio.to_thread(fetch_cached, symbol, TF_4H, 120)

        # 1) управление всеми открытыми позициями (трейлинг + выход)
        open_positions = db.get_all_positions()
        for pos in open_positions:
            df15 = df_15m_map.get(pos["symbol"])
            df4 = df_4h_map.get(pos["symbol"])
            if df15 is not None:
                df15i = compute_15m_indicators(df15)
                closed, idx = last_closed_candle(df15i, TF_15M_SEC)
                await manage_open_position(bot, pos, df15i, df4, idx)

        # 2) поиск входа (пока слотов < MAX_POSITIONS и макро бычий)
        if btc_bullish:
            await try_open_position(bot, df_15m_map, df_4h_map, btc_bullish)

        # 3) запись эквити (раз в 5 минут) — суммарно по всем позициям
        global _last_equity_ts
        now = time.time()
        if now - _last_equity_ts > 300:
            balance = db.get_balance()
            unreal = 0.0
            for pos in db.get_all_positions():
                df15 = df_15m_map.get(pos["symbol"])
                if df15 is not None and len(df15) > 0:
                    last_close = df15.iloc[-1]["close"]
                    unreal += (last_close - pos["entry_price"]) / pos["entry_price"] * pos["notional"]
            db.add_equity_point(int(now * 1000), balance + unreal, balance)
            _last_equity_ts = now

    except Exception as e:
        log.exception("strategy_cycle error: %s", e)


# ============================== Статистика ==================================
def compute_stats():
    trades = db.get_closed_trades_for_stats()
    n = len(trades)
    if n == 0:
        return {"total": 0, "wins": 0, "losses": 0, "winrate": 0.0,
                "profit_factor": 0.0, "max_drawdown_pct": 0.0,
                "total_pnl": 0.0, "final_balance": db.get_balance()}
    wins = [t for t in trades if t["net_pnl"] > 0]
    losses = [t for t in trades if t["net_pnl"] <= 0]
    gp = sum(t["net_pnl"] for t in wins)
    gl = abs(sum(t["net_pnl"] for t in losses))
    pf = (gp / gl) if gl > 0 else float("inf")

    # макс. просадка по equity-кривой
    eq = db.get_equity_curve()
    max_dd = 0.0
    if eq:
        peak = eq[0]["equity"]
        for e in eq:
            if e["equity"] > peak:
                peak = e["equity"]
            dd = (peak - e["equity"]) / peak * 100 if peak > 0 else 0
            if dd > max_dd:
                max_dd = dd

    balance = db.get_balance()
    return {
        "total": n, "wins": len(wins), "losses": len(losses),
        "winrate": len(wins) / n * 100, "profit_factor": pf,
        "max_drawdown_pct": max_dd,
        "total_pnl": balance - db.get_start_balance(),
        "final_balance": balance,
    }


# ============================== График ======================================
async def generate_equity_chart():
    eq = db.get_equity_curve()
    if not eq or len(eq) < 2:
        return None
    ts = [datetime.fromtimestamp(e["ts"] / 1000, tz=timezone.utc) for e in eq]
    equity = [e["equity"] for e in eq]
    balance = [e["balance"] for e in eq]
    start = db.get_start_balance()

    fig, ax = plt.subplots(figsize=(11, 5.5))
    ax.plot(ts, equity, color="#16a34a", linewidth=2.2, label="Equity")
    ax.plot(ts, balance, color="#64748b", linewidth=1.2, linestyle="--", alpha=0.7, label="Balance")
    ax.fill_between(ts, equity, min(min(equity), start) - 5, alpha=0.12, color="#16a34a")
    ax.axhline(start, color="#94a3b8", linewidth=0.8, linestyle=":", label=f"Start ${start:.0f}")
    ax.set_title("Equity Curve — Market Structure Accelerated (15m)", fontsize=13, fontweight="bold")
    ax.set_ylabel("Equity ($)", fontsize=11)
    ax.set_xlabel("Дата (UTC)", fontsize=10)
    ax.grid(True, alpha=0.25)
    ax.legend(loc="upper left", fontsize=9)
    fig.autofmt_xdate()
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=110, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    buf.seek(0)
    return buf


# ============================== Telegram-команды ============================
def is_admin(msg: Message) -> bool:
    return TELEGRAM_ADMIN_ID is not None and msg.from_user and msg.from_user.id == TELEGRAM_ADMIN_ID


async def cmd_start(message: Message):
    if not is_admin(message):
        await message.answer("⛔ Вы не администратор этого бота.")
        return
    await message.answer(
        f"🤖 <b>Market Structure Accelerated (15m)</b>\n"
        f"Paper Trading · Long-Only · Unthrottled\n\n"
        f"📊 Пары: {', '.join(ACTIVE_SYMBOLS or SYMBOLS)}\n"
        f"🏦 Плечо: {LEVERAGE}x  |  Риск: {RISK_PERCENT*100:.1f}%\n"
        f"📈 Биржа: {EXCHANGE_NAME.upper()}\n\n"
        f"Команды:\n"
        f"/balance — баланс, эквити, uPnL\n"
        f"/stats — статистика (винрейт, PF, просадка)\n"
        f"/position — активная позиция\n"
        f"/chart — график кривой баланса\n"
        f"\n⚡ Бот исполняет 100% сигналов 24/7 (без предохранителей).")


async def cmd_balance(message: Message):
    if not is_admin(message):
        await message.answer("⛔ Недостаточно прав.")
        return
    balance = db.get_balance()
    start = db.get_start_balance()
    positions = db.get_all_positions()
    unreal = 0.0
    pos_lines = []
    for pos in positions:
        try:
            df = await asyncio.to_thread(fetch_cached, pos["symbol"], TF_15M, 100)
            if df is not None and len(df) > 0:
                last_close = df.iloc[-1]["close"]
                u = (last_close - pos["entry_price"]) / pos["entry_price"] * pos["notional"]
                unreal += u
                pos_lines.append(f"  · {pos['symbol']} LONG @ ${pos['entry_price']:,.4f} | "
                                 f"SL ${pos['stop_loss']:,.4f} | uPnL {fmt_money(u)}$")
        except Exception:
            pos_lines.append(f"  · {pos['symbol']} LONG @ ${pos['entry_price']:,.4f} | "
                             f"SL ${pos['stop_loss']:,.4f}")
    equity = balance + unreal
    total_pnl = balance - start
    pos_block = "\n".join(pos_lines) if pos_lines else "📌 Нет открытых позиций"
    await message.answer(
        f"💼 <b>Баланс и эквити</b>  ·  {len(positions)}/{MAX_POSITIONS} поз.\n"
        f"━━━━━━━━━━━━━━━━━━━━\n"
        f"💰 Баланс: <b>${balance:,.2f}</b>\n"
        f"📈 Эквити: <b>${equity:,.2f}</b>\n"
        f"📊 Нереализованный PnL: <b>{fmt_money(unreal)}$</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━\n"
        f"🟢 Старт: ${start:,.2f}  |  Реализованный PnL: {fmt_money(total_pnl)}$\n"
        f"{pos_block}")


async def cmd_stats(message: Message):
    if not is_admin(message):
        await message.answer("⛔ Недостаточно прав.")
        return
    s = compute_stats()
    pf = "∞" if s["profit_factor"] == float("inf") else f"{s['profit_factor']:.2f}"
    await message.answer(
        f"📊 <b>Статистика</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━\n"
        f"📦 Сделок: <b>{s['total']}</b>\n"
        f"✅ Победы: <b>{s['wins']}</b>  ❌ Поражения: <b>{s['losses']}</b>\n"
        f"🏆 Винрейт: <b>{s['winrate']:.1f}%</b>\n"
        f"💵 Профит-фактор: <b>{pf}</b>\n"
        f"📉 Макс. просадка: <b>{s['max_drawdown_pct']:.2f}%</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━\n"
        f"💰 Чистый PnL: <b>{fmt_money(s['total_pnl'])}$</b>\n"
        f"💵 Текущий баланс: <b>${s['final_balance']:,.2f}</b>")


async def cmd_position(message: Message):
    if not is_admin(message):
        await message.answer("⛔ Недостаточно прав.")
        return
    positions = db.get_all_positions()
    if not positions:
        await message.answer("📭 <b>Открытых позиций нет</b>\nБот вне рынка.")
        return
    lines = [f"📌 <b>Открытые позиции ({len(positions)}/{MAX_POSITIONS})</b>"]
    for pos in positions:
        try:
            df = await asyncio.to_thread(fetch_cached, pos["symbol"], TF_15M, 100)
            last_close = df.iloc[-1]["close"] if df is not None else pos["entry_price"]
        except Exception:
            last_close = pos["entry_price"]
        unreal = (last_close - pos["entry_price"]) / pos["entry_price"] * pos["notional"]
        pnl_pct = unreal / pos["margin"] * 100 if pos["margin"] else 0
        lines.append("━━━━━━━━━━━━━━━━━━━━")
        lines.append(f"📈 {pos['symbol']} — LONG")
        lines.append(f"💰 Вход: ${pos['entry_price']:,.4f} → ${last_close:,.4f}")
        lines.append(f"📊 Размер: ${pos['notional']:,.2f} (маржа ${pos['margin']:,.2f})")
        lines.append(f"📦 Объём: {pos['qty']:.4f}")
        lines.append(f"🛑 Трейлинг SL: ${pos['stop_loss']:,.4f}")
        lines.append(f"📊 Плавающий PnL: <b>{fmt_money(unreal)}$</b> ({fmt_money(pnl_pct)}%)")
        lines.append(f"⏱ Открыта: {pos['open_ts'][:19].replace('T',' ')} UTC")
    await message.answer("\n".join(lines))


async def cmd_chart(message: Message):
    if not is_admin(message):
        await message.answer("⛔ Недостаточно прав.")
        return
    buf = await generate_equity_chart()
    if buf is None:
        await message.answer("📭 Недостаточно данных для графика. Подождите积累 точки эквити (раз в 5 мин).")
        return
    s = compute_stats()
    pf = "∞" if s["profit_factor"] == float("inf") else f"{s['profit_factor']:.2f}"
    caption = (f"📈 Equity Curve · MS Accelerated (15m)\n"
               f"Сделок: {s['total']} | WR {s['winrate']:.1f}% | PF {pf} | "
               f"DD {s['max_drawdown_pct']:.1f}% | Баланс ${s['final_balance']:,.2f}")
    await message.answer_photo(buf, caption=caption)


# ============================== Точка входа =================================
async def main():
    db.init_db(START_BALANCE)

    if not TELEGRAM_BOT_TOKEN:
        raise RuntimeError("TELEGRAM_BOT_TOKEN не задан. Заполните .env (см. .env.example).")
    if TELEGRAM_ADMIN_ID is None:
        raise RuntimeError("TELEGRAM_ADMIN_ID не задан или не число.")

    # Фильтр символов по доступности на бирже
    await asyncio.to_thread(load_available_symbols)

    bot = Bot(token=TELEGRAM_BOT_TOKEN,
              default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    dp = Dispatcher()
    dp.message.register(cmd_start, Command("start"))
    dp.message.register(cmd_balance, Command("balance"))
    dp.message.register(cmd_stats, Command("stats"))
    dp.message.register(cmd_position, Command("position"))
    dp.message.register(cmd_chart, Command("chart"))

    # баннер
    active = ACTIVE_SYMBOLS or SYMBOLS
    print("=" * 70)
    print("  MARKET STRUCTURE ACCELERATED (15m) — Paper Trading Bot")
    print("=" * 70)
    print(f"  Биржа      : {EXCHANGE_NAME.upper()}")
    print(f"  Пары       : {', '.join(active)}  ({len(active)}/{len(SYMBOLS)} доступно)")
    print(f"  BTC макро  : {BTC_SYMBOL} 1D > EMA({MACRO_EMA_LEN})")
    print(f"  Плечо      : {LEVERAGE}x  |  Риск: {RISK_PERCENT*100:.1f}%  |  Макс. позиций: {MAX_POSITIONS}")
    print(f"  Комиссия   : {ROUND_TRIP_COST*100:.2f}% за круг")
    print(f"  Цикл       : каждые {CYCLE_SECONDS}с  (БЕЗ предохранителей)")
    print(f"  Telegram   : {'ON (admin=' + str(TELEGRAM_ADMIN_ID) + ')' if TELEGRAM_ADMIN_ID else 'OFF'}")
    print(f"  БД         : {db.DB_PATH}")
    print("=" * 70)

    # планировщик: основной цикл стратегии
    scheduler = AsyncIOScheduler()
    scheduler.add_job(strategy_cycle, "interval", seconds=CYCLE_SECONDS,
                      args=[bot], max_instances=1, coalesce=True, name="strategy")
    scheduler.start()
    log.info("Бот запущен. Цикл каждые %ss. Long-only, без предохранителей.", CYCLE_SECONDS)

    # первый прогон сразу
    await strategy_cycle(bot)

    await dp.start_polling(bot, allowed_updates=["message"])


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except (KeyboardInterrupt, SystemExit):
        log.info("Остановка бота.")
